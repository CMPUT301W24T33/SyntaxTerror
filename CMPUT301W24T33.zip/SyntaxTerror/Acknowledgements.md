# Acknowledgements

// OpenAI, 2024, ChatGPT, XML Generation, Java Method Refactoring, Setting Up Custom Recycler Adapters, JavaDoc Commenting

// Zxing Authors, 2008, Zxing project, used for QR code encoding in QRCode class.

// Wware Consulting, 2024, GITUML, make UML
