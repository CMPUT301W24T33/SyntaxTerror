# SyntaxTerror

Welcome to the SyntaxTerror repo! Check our [wiki](https://github.com/CMPUT301W24T33/SyntaxTerror/wiki) for details on the project design.
